from django.shortcuts import render
from django.views import generic, View
from django.conf import settings

# Create your views here.

class TemplateView(generic.ListView):
    template_name = "home/main.html"
