from django.db import models
from django.core.validators import MinLengthValidator

# Create your models here.


class Breed(models.Model):

    name = models.CharField(max_length=200 , validators= [MinLengthValidator(2, "Breed needs at least 2 characters")])

    def __str__(self):

        return self.name


class Cat(models.Model):

    nickname = models.CharField(max_length= 200, validators = [MinLengthValidator(2,"Needs at least 2 characters!")])
    weight = models.FloatField()
    foods = models.CharField(max_length = 200 , blank= True)
    breed = models.ForeignKey("Breed" ,on_delete = models.CASCADE, null=False)

    def __str__(self):

        return self.nickname