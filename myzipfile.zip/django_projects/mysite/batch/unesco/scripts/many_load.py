import csv  # https://docs.python.org/3/library/csv.html

# https://django-extensions.readthedocs.io/en/latest/runscript.html

# python3 manage.py runscript many_load

from unesco.models import Category , State ,  Iso , Region , Site


def run():
    fhand = open('unesco/whc-sites-2018-clean.csv')
    reader = csv.reader(fhand)
    next(reader)  # Advance past the header

    #Person.objects.all().delete()
    #Course.objects.all().delete()
    #Membership.objects.all().delete()

    # Format
    # email,role,course
    # jane@tsugi.org,I,Python
    # ed@tsugi.org,L,Python

    Category.objects.all().delete()
    State.objects.all().delete()
    Iso.objects.all().delete()
    Region.objects.all().delete()
    Site.objects.all().delete()

    for row in reader:
        print(row)

        #rows are the from the column number in the og file!

        na = row[0]
        des = row[1]
        jus = row[2]
        y = row[3]
        lo = row[4]
        la = row[5]
        try:
            a = float(row[6])
        except:
            a = 1


        c , created = Category.objects.get_or_create(name=row[7])
        c.save()
        s , created = State.objects.get_or_create(name=row[8])
        s.save()
        r , created = Region.objects.get_or_create(name=row[9])
        r.save()
        i , created = Iso.objects.get_or_create(name=row[10])
        i.save()


        make_tables = Site(name = na , year = y , latitude = la , longitude = lo, description = des, justification = jus , area_hectares = a,
        category = c , state= s , iso = i , region = r)

        make_tables.save()

        '''p, created = Person.objects.get_or_create(email=row[0])
        c, created = Course.objects.get_or_create(title=row[2])

        r = Membership.LEARNER
        if row[1] == 'I':
            r = Membership.INSTRUCTOR
        m = Membership(role=r, person=p, course=c)
        m.save()'''