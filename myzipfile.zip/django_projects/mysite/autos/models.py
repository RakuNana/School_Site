from django.db import models
from django.core.validators import MinLengthValidator

# Create your models here.

class Make(models.Model):

    name = models.CharField( max_length=200, help_text="Enter a car make(Pontiac)",validators=[MinLengthValidator(3,"Name can't be less than 3 characters")])

    def __str__(self):
        "This is to show a String of the object we are looking at"

        return self.name


class Auto(models.Model):

    nickname = models.CharField(max_length=200, validators=[MinLengthValidator(2," Two or more characters needed!")])

    mileage = models.PositiveIntegerField()
    remarks = models.CharField(max_length=200, blank=True)
    make = models.ForeignKey("Make", on_delete=models.CASCADE, null=False)
    comments = models.CharField(max_length =200)

    "Displays in our admin list, Hurray!"

    def __str__(self):

        return self.nickname